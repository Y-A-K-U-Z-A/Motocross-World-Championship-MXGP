package motocrossWorldChampionship.repositories.interfaces;

import motocrossWorldChampionship.entities.interfaces.Motorcycle;
import motocrossWorldChampionship.entities.interfaces.Race;

import java.util.ArrayList;
import java.util.Collection;

public class RaceRepository implements Repository {
    private Collection<Race> races;

    public RaceRepository() {
        this.races = new ArrayList<>();
    }


    @Override
    public Race getByName(String name) {
        for (Race race : races) {
            if (race.getName().equals(name)){
                return race;
            }
        }
        return null;
    }

    @Override
    public Collection<Race> getAll() {
        return races;
    }

    @Override
    public void add(Object model) {
        races.add((Race) model);
    }

    @Override
    public boolean remove(Object model) {
        Race race = null;
        for (Race race1 : races) {
            if (race1.equals(model)){
                race = race1;
            }
        }
        if (race != null){
            races.remove(race);
            return true;
        }
        return false;
    }
}
