package motocrossWorldChampionship.core;

import motocrossWorldChampionship.core.interfaces.Engine;
import motocrossWorldChampionship.entities.interfaces.Motorcycle;
import motocrossWorldChampionship.entities.interfaces.Race;
import motocrossWorldChampionship.entities.interfaces.Rider;
import motocrossWorldChampionship.io.ConsoleReader;
import motocrossWorldChampionship.io.ConsoleWriter;
import motocrossWorldChampionship.io.interfaces.InputReader;
import motocrossWorldChampionship.io.interfaces.OutputWriter;
import motocrossWorldChampionship.repositories.interfaces.MotorcycleRepository;
import motocrossWorldChampionship.repositories.interfaces.RaceRepository;
import motocrossWorldChampionship.repositories.interfaces.Repository;
import motocrossWorldChampionship.repositories.interfaces.RiderRepository;


import java.io.IOException;

public class EngineImpl implements Engine{
    private InputReader reader;
    private OutputWriter writer;
    private ChampionshipControllerImpl controller;


    public EngineImpl() {
        Repository<Rider> riderRepository = new RiderRepository();
        Repository<Motorcycle> motorcycleRepository = new MotorcycleRepository();
        Repository<Race> raceRepository = new RaceRepository();

        controller = new ChampionshipControllerImpl(riderRepository, motorcycleRepository,raceRepository);
        this.reader = new ConsoleReader();
        this.writer = new ConsoleWriter();
    }

    @Override
    public void run(){
//        String line ;
//        try {
//            line = readLine();
//            while (!line.equals("End")){
//                try {
//                   writeLine(line);
//                }catch (Exception e){
//                    System.out.println(e.getMessage());
//                }
//                line = readLine();
//            }
//        }catch (Exception e){
//            System.out.println(e.getMessage());
//        }

        while (true) {
            String result = null;
            try {
                result = processInput();

                if ("End".equals(result)) {
                    break;
                }

            } catch (IOException | IllegalArgumentException | NullPointerException e) {
                result = e.getMessage();
            }
                if (result.equals("End")){
                    break;
                }
            this.writer.writeLine(result);
        }
    }

    private String processInput() throws IOException {
        String input = this.reader.readLine();
        String[] tokens = input.split("\\s");

        String out = "";

        switch (tokens[0]){
            case "CreateRider":
                out = controller.createRider(tokens[1]);
                break;
            case "CreateMotorcycle":
                out = controller.createMotorcycle(tokens[1],tokens[2], Integer.parseInt(tokens[3]));
                break;
            case "AddMotorcycleToRider":
                out = controller.addMotorcycleToRider(tokens[1], tokens[2]);
                break;
            case "AddRiderToRace":
                out = controller.addRiderToRace(tokens[1], tokens[2]);
                break;
            case "CreateRace":
                out = controller.createRace(tokens[1], Integer.parseInt(tokens[2]));
                break;
            case "StartRace":
                out = controller.startRace(tokens[1]);
                break;
            case "End" :
                out = "End";
                break;
        }

        return out;
    }

//
//    public void writeLine(String text) {
//        String[] tokens = text.split("\\s+");
//
//        String out = "";
//
//        switch (tokens[0]){
//            case "CreateRider":
//                out = controller.createRider(tokens[1]);
//                break;
//            case "CreateMotorcycle":
//                out = controller.createMotorcycle(tokens[1],tokens[2], Integer.parseInt(tokens[3]));
//                break;
//            case "AddMotorcycleToRider":
//                out = controller.addMotorcycleToRider(tokens[1], tokens[2]);
//                break;
//            case "AddRiderToRace":
//                out = controller.addRiderToRace(tokens[1], tokens[2]);
//                break;
//            case "CreateRace":
//                out = controller.createRace(tokens[1], Integer.parseInt(tokens[2]));
//                break;
//            case "StartRace":
//                out = controller.startRace(tokens[1]);
//                break;
//            case "End" :
//                break;
//        }
//        System.out.println(out);
//    }
}
