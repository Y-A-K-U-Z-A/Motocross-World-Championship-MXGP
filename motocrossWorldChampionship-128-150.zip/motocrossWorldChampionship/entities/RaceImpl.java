package motocrossWorldChampionship.entities;

import motocrossWorldChampionship.entities.interfaces.Race;
import motocrossWorldChampionship.entities.interfaces.Rider;

import java.util.ArrayList;
import java.util.Collection;

public class RaceImpl implements Race {
    private String name;
    private int laps;
    private Collection<Rider> riders;

    public RaceImpl(String name, int laps) {
        riders = new ArrayList<>();
        this.setName(name);
        this.setLaps(laps);
    }

    private void setName(String name) {
        if (name == null || name.trim().isEmpty() || name.trim().length() < 5){
            throw new IllegalArgumentException("Name " + name + " cannot be less than 5 symbols.");
        }
        this.name = name;
    }

    private void setLaps(int laps) {
        if (laps < 1){
            throw new IllegalArgumentException("Laps cannot be less than 1.");
        }
        this.laps = laps;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public int getLaps() {
        return laps;
    }

    @Override
    public Collection<Rider> getRiders() {
        return riders;
    }

    @Override
    public void addRider(Rider rider) {
        if (rider == null){
            throw new NullPointerException("Rider cannot be null.");
        }
        if (!rider.getCanParticipate()){
            throw new IllegalArgumentException("Rider " + rider.getName() + " could not participate in race.");
        }
        if (riderAlreadyExist(rider)){
            throw new IllegalArgumentException("Rider " + rider.getName() + " is already added in " + name + " race.");
        }
        riders.add(rider);
    }

    private boolean riderAlreadyExist(Rider rider) {
        for (Rider rider1 : riders) {
            if (rider.equals(rider1)){
                return true;
            }
        }
        return false;
    }

}
