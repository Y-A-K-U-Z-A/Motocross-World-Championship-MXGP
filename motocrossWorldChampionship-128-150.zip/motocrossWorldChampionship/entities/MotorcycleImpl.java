package motocrossWorldChampionship.entities;

import motocrossWorldChampionship.entities.interfaces.Motorcycle;

public abstract class MotorcycleImpl implements Motorcycle {
   private String model;
   private int horsePower;
   private double cubicCentimeters;

    public MotorcycleImpl(String model, int horsePower, double cubicCentimeters) {
        this.setModel(model);
        this.setHorsePowers(horsePower);
        this.setCubicCentimeters(cubicCentimeters);
    }

    protected void setCubicCentimeters(double cubicCentimeters) {
        this.cubicCentimeters = cubicCentimeters;
    }

    protected void setHorsePowers(int horsePower) {
        this.horsePower = horsePower;        //TODO override
    }

    protected void setModel(String model){
        if (model == null || model.trim().isEmpty() || model.trim().length() < 4 ){
            throw new IllegalArgumentException("Model " + model + " cannot be less than 4 symbols.");
        }
        this.model = model;
    }

    @Override
    public String getModel() {
        return this.model;
    }

    @Override
    public int getHorsePower() {
        return horsePower;
    }

    @Override
    public double getCubicCentimeters() {
        return cubicCentimeters;
    }

    @Override
    public double calculateRacePoints(int laps) {
        return cubicCentimeters / horsePower * laps;
    }
}
