package motocrossWorldChampionship;

import motocrossWorldChampionship.core.ChampionshipControllerImpl;
import motocrossWorldChampionship.core.EngineImpl;
import motocrossWorldChampionship.core.interfaces.Engine;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        EngineImpl engine = new EngineImpl();
        engine.run();

    }
}
