package motocrossWorldChampionship.repositories.interfaces;

import motocrossWorldChampionship.entities.interfaces.Motorcycle;
import motocrossWorldChampionship.entities.interfaces.Rider;

import java.util.ArrayList;
import java.util.Collection;

public class RiderRepository implements Repository{
    private Collection<Rider> riders;

    public RiderRepository() {
        riders = new ArrayList<>();
    }

    @Override
    public Rider getByName(String name) {
        for (Rider rider : riders) {
            if (rider.getName().equals(name)){
                return rider;
            }
        }
        return null;
    }

    @Override
    public Collection<Rider> getAll() {
        return riders;
    }

    @Override
    public void add(Object model) {
        for (Rider rider : riders) {
            if (rider.equals((Rider)model)){
                throw new IllegalArgumentException("Rider " + rider.getName()+ " is already created.");
            }
        }
        riders.add((Rider) model);
    }

    @Override
    public boolean remove(Object model) {
        Rider rider = null;
        for (Rider rider1 : riders) {
            if (rider1.equals(model)){
                rider = rider1;
            }
        }
        if (rider != null ){
            riders.remove(rider);
            return true;
        }
        return false;
    }
}
