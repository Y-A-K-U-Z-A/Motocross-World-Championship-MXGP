package motocrossWorldChampionship.repositories.interfaces;

import motocrossWorldChampionship.entities.interfaces.Motorcycle;

import java.util.ArrayList;
import java.util.Collection;

public class MotorcycleRepository implements Repository{
    private Collection<Motorcycle> motorcycles;

    public MotorcycleRepository() {
        this.motorcycles = new ArrayList<>();
    }

    @Override
    public Motorcycle getByName(String name) {
        for (Motorcycle motorcycle : motorcycles) {
            if (motorcycle.getModel().equals(name)){
                return motorcycle;
            }
        }
        return null;
    }

    @Override
    public Collection<Motorcycle> getAll() {
        return motorcycles;
    }

    @Override
    public void add(Object model) {
        motorcycles.add((Motorcycle) model);
    }

    @Override
    public boolean remove(Object model) {
        Motorcycle toRemove = null;
        for (Motorcycle motorcycle : motorcycles) {
            if (motorcycle.equals(model)){
                toRemove = motorcycle;
            }
        }
        if (toRemove != null){
            motorcycles.remove(toRemove);
            return true;
        }
        return false;
    }
}
