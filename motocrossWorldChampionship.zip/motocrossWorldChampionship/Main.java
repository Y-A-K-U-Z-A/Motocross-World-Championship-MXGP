package motocrossWorldChampionship;

import motocrossWorldChampionship.core.interfaces.EngineImpl;

public class Main {
    public static void main(String[] args) {
        EngineImpl engine = new EngineImpl();
        engine.run();
    }
}
