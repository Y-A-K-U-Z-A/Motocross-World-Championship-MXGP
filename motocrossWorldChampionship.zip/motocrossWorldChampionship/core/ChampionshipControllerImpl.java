package motocrossWorldChampionship.core;

import motocrossWorldChampionship.common.ExceptionMessages;
import motocrossWorldChampionship.common.OutputMessages;
import motocrossWorldChampionship.core.interfaces.ChampionshipController;
import motocrossWorldChampionship.entities.PowerMotorcycle;
import motocrossWorldChampionship.entities.RaceImpl;
import motocrossWorldChampionship.entities.RiderImpl;
import motocrossWorldChampionship.entities.SpeedMotorcycle;
import motocrossWorldChampionship.entities.interfaces.Motorcycle;
import motocrossWorldChampionship.entities.interfaces.Race;
import motocrossWorldChampionship.entities.interfaces.Rider;
import motocrossWorldChampionship.repositories.interfaces.MotorcycleRepository;
import motocrossWorldChampionship.repositories.interfaces.RaceRepository;
import motocrossWorldChampionship.repositories.interfaces.Repository;
import motocrossWorldChampionship.repositories.interfaces.RiderRepository;

import java.awt.*;
import java.util.*;
import java.util.List;
import java.util.stream.Collectors;

public class ChampionshipControllerImpl extends OutputMessages implements ChampionshipController {
    private RiderRepository riderRepository;
    private MotorcycleRepository motorcycleRepository;
    private RaceRepository raceRepository;

    public ChampionshipControllerImpl() {
        riderRepository = new RiderRepository();
        motorcycleRepository = new MotorcycleRepository();
        raceRepository = new RaceRepository();
    }

    @Override
    public String createRider(String riderName) {
        Rider rider = new RiderImpl(riderName);
        if (repositoryContainsRider(rider)) {
            throw new IllegalArgumentException(
                    String.format(ExceptionMessages.RIDER_EXISTS, riderName));
        }
        riderRepository.add(rider);
        return String.format(RIDER_CREATED, riderName);
    }

    private boolean repositoryContainsRider(Rider rider) {
        for (Rider rider1 : riderRepository.getAll()) {
            if (rider.getName().equals(rider1.getName())){
                return true;
            }
        }
        return false;
    }


    @Override
    public String createMotorcycle(String type, String model, int horsePower) {
            Motorcycle motorcycle = createMotorCycleWithType(type, model, horsePower);
            if(repositoryContains(motorcycle, motorcycleRepository)){
                throw new IllegalArgumentException(String.format(ExceptionMessages.MOTORCYCLE_EXISTS, model));
            }
            motorcycleRepository.add(motorcycle);
            return String.format(OutputMessages.MOTORCYCLE_CREATED, type+"Motorcycle", model);
    }

    private boolean repositoryContains(Motorcycle motorcycle, MotorcycleRepository motorcycleRepository) {
        for (Motorcycle motorcycle1 : motorcycleRepository.getAll()) {
            if (motorcycle.getModel().equals(motorcycle1.getModel())){
                return true;
            }
        }
        return false;
    }

    private Motorcycle createMotorCycleWithType(String type, String model, int horsePower) {
        switch (type){
            case "Speed":
                return new SpeedMotorcycle(model, horsePower);
            case "Power":
                return new PowerMotorcycle(model, horsePower);
        }
        return null;
    }

    @Override
    public String addMotorcycleToRider(String riderName, String motorcycleModel) {
        Motorcycle motorcycle = findMotorcycle(motorcycleModel);
        Rider rider = findRider(riderName);

        if (rider == null){
            throw new NullPointerException(String.format(ExceptionMessages.RIDER_NOT_FOUND, riderName));
        }
        if (motorcycle == null){
            throw new NullPointerException(String.format(ExceptionMessages.MOTORCYCLE_NOT_FOUND, motorcycleModel));
        }
        rider.addMotorcycle(motorcycle);
        return String.format(OutputMessages.MOTORCYCLE_ADDED, riderName, motorcycle.getModel());
    }

    private Rider findRider(String riderName) {
        Rider rider = null;
        for (Rider rider1 : riderRepository.getAll()) {
            if (rider1.getName().equals(riderName)){
                rider = rider1;
            }
        }
        return rider;
    }

    private Motorcycle findMotorcycle(String motorcycleModel) {
        Motorcycle motorcycle = null;
        for (Motorcycle motorcycle1 : motorcycleRepository.getAll()) {
            if (motorcycle1.getModel().equals(motorcycleModel)){
                motorcycle = motorcycle1;
            }
        }
        return motorcycle;
    }

    @Override
    public String addRiderToRace(String raceName, String riderName) {
        Race race = findRace(raceName);
        Rider rider = findRider(riderName);
        if (race == null){
            throw new NullPointerException(String.format(ExceptionMessages.RACE_NOT_FOUND, raceName));
        }
        if (rider == null){
            throw new NullPointerException(String.format(ExceptionMessages.RIDER_NOT_FOUND, riderName));
        }
        race.addRider(rider);
        return String.format(OutputMessages.RIDER_ADDED, riderName, raceName);
    }

    private Race findRace(String raceName) {
        for (Race race : raceRepository.getAll()) {
            if (race.getName().equals(raceName)){
                return race;
            }
        }
        return null;
    }

    @Override
    public String startRace(String raceName) {
        Race race = raceRepository.getByName(raceName);

        if (!containsRace(race)){
            throw new NullPointerException(String.format(ExceptionMessages.RACE_NOT_FOUND, raceName));
        }
        if (race.getRiders().size() < 3){
            throw new IllegalArgumentException(String.format(ExceptionMessages.RACE_INVALID, raceName,3));
        }

        int laps = race.getLaps();

        return sortRiders(laps, race);
    }

    private String sortRiders(int laps, Race race) {
        double first, second, third;

        third = first = second = Double.MIN_VALUE;

       List<Rider> sorted = new ArrayList<>();
       sorted.add(0, null);
       sorted.add(1, null);
       sorted.add(2, null);

        String out = "";

        List<Rider> riders = race.getRiders().stream().collect(Collectors.toUnmodifiableList());


        int stop = riders.size();

           for (int i = 0; i < stop; i++) {
               double current = riders.get(i).getMotorcycle().calculateRacePoints(laps);

               if (current >= first){
                   third = second;
                   second = first;
                   first = current;
                   sorted.set(2, sorted.get(1));
                   sorted.set(1, sorted.get(0));
                   sorted.set(0, riders.get(i));
               }else if (current >= second){
                   third = second;
                   second = current;
                   sorted.set(2, sorted.get(1));
                   sorted.set(1, riders.get(i));
               }else if (current >= third){
                   third = current;
                   sorted.set(2, riders.get(i));
               }
           }

        out += writeTopRiders(sorted, race.getName()).trim();

       return out;
    }

    private String writeTopRiders(List<Rider> sorted, String name) {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("Rider %s wins %s race.%n", sorted.get(0).getName(), name));
        sb.append(String.format("Rider %s is second in %s race.%n", sorted.get(1).getName(), name));
        sb.append(String.format("Rider %s is third in %s race.%n", sorted.get(2).getName(), name));
        return sb.toString();
    }

    @Override
    public String createRace(String name, int laps) {
        Race race = new RaceImpl(name, laps);
        if (containsRace(race)){
            throw new IllegalArgumentException(String.format(ExceptionMessages.RACE_EXISTS, name));
        }
        raceRepository.add(race);
        return String.format(OutputMessages.RACE_CREATED, name);
    }

    private boolean containsRace(Race race) {
        for (Race race1 : raceRepository.getAll()) {
            if (race1.equals(race)){
                return true;
            }
        }
        return false;
    }


}
