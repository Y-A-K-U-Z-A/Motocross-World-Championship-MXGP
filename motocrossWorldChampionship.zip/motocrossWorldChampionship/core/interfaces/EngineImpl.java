package motocrossWorldChampionship.core.interfaces;

import motocrossWorldChampionship.core.ChampionshipControllerImpl;
import motocrossWorldChampionship.io.interfaces.InputReader;
import motocrossWorldChampionship.io.interfaces.OutputWriter;

import java.io.IOException;
import java.util.Scanner;

public class EngineImpl implements Engine{

private static Scanner sc = new Scanner(System.in);
private  ChampionshipControllerImpl controller;

    public EngineImpl() {
        controller = new ChampionshipControllerImpl();
    }

    @Override
    public void run(){
        String line = "";
        
            while (!line.equals("End")){
                try {
                   writeLine(line);
                }catch (Exception e){
                    System.out.println(e.getMessage());
                }
                line = readLine();
            }


    }


    public String readLine() {
        return sc.nextLine();
    }


    public void writeLine(String text) {
        String[] tokens = text.split("\\s+");

        String out = "";

        switch (tokens[0]){
            case "CreateRider":
                out = controller.createRider(tokens[1]);
                break;
            case "CreateMotorcycle":
                out = controller.createMotorcycle(tokens[1],tokens[2], Integer.parseInt(tokens[3]));
                break;
            case "AddMotorcycleToRider":
                out = controller.addMotorcycleToRider(tokens[1], tokens[2]);
                break;
            case "AddRiderToRace":
                out = controller.addRiderToRace(tokens[1], tokens[2]);
                break;
            case "CreateRace":
                out = controller.createRace(tokens[1], Integer.parseInt(tokens[2]));
                break;
            case "StartRace":
                out = controller.startRace(tokens[1]);
                break;
            case "End" :
                break;
        }
        System.out.println(out);
    }
}
